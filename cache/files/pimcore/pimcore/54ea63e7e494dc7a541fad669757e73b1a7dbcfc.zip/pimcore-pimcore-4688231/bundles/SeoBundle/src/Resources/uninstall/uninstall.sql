DROP TABLE IF EXISTS `http_error_log`;
DROP TABLE IF EXISTS `redirects`;