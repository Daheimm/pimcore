#### v4.0.0
 - Added primary key to `plugin_cmf_deletions` table.
 - Removed the package "hwi/oauth-bundle".
 - Removed the support of  Single Sign On (SSO) implementation.
 - Removed the config `pimcore_customer_management_framework.oauth_client`.

##### v3.4
- The Single Sign On (SSO) functionality is deprecated and will be removed in version 4.

#### v3.3.0
- Deprecated `DefaultCustomerProvider::getParentParentPath()`. Use  `getParentPath()` instead.
