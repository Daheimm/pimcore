# Checkout Manager Details

Following documentation page provide a few more insights on Checkout Manager Architecture. 
### Architecture Details

![Architecture V7](../img/PaymentWorkflowV7.svg)

* Stars mark places, where events are thrown. For details see [EventManager docs](https://github.com/pimcore/pimcore/tree/11.x/doc/20_Extending_Pimcore/11_Event_API_and_Event_Manager.md).

 