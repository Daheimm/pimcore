<?php

namespace OldSound\RabbitMqBundle\Event;

use Symfony\Contracts\EventDispatcher\Event as ContractsBaseEvent;

abstract class AbstractAMQPEvent extends ContractsBaseEvent
{
}
