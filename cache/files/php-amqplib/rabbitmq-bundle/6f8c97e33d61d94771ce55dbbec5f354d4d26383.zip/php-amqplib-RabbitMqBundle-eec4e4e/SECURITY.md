# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.0  | :white_check_mark: |
| 1.0 | :x:                |

## Reporting a Vulnerability

If you discover a security vulnerability, please send an email at mihai.leu@emag.ro.
