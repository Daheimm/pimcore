# Formatting and Output

*phpgeo* is able to output supported Geometry instances in many different
formats. You're able to provide your own Formatter classes for customization
of the output format.
