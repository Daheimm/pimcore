<?php

declare(strict_types=1);

namespace Location\Exception;

class InvalidGeometryException extends \RuntimeException
{
}
