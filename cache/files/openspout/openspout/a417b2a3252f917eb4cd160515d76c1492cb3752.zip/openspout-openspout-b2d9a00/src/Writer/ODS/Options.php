<?php

declare(strict_types=1);

namespace OpenSpout\Writer\ODS;

use OpenSpout\Writer\Common\AbstractOptions;

final class Options extends AbstractOptions {}
